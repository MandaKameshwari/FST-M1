import pytest


def test_divisible_by_4(numdata):
    assert numdata % 4 == 0

def test_divisible_by_2(numdata):
    assert numdata % 3 == 0
